"""Maritime Radar AI Control Center — unified Streamlit interface.

Start after `python scripts/generate_data.py` and optionally training:
    streamlit run app.py

The dashboard is explicitly a synthetic proof-of-concept. No output is
certified or fit for navigational decisions.
"""
import json
import subprocess
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.geometry import NM, vector_from_course
from maritime_ai.replay import ReplayEngine

CONFIG = load_config()
COLOR = {'01': '#fb923c', '02': '#facc15', '03': '#4ade80'}

st.set_page_config(page_title='Maritime Radar AI | Synthetic POC',
                   page_icon='🛳️', layout='wide', initial_sidebar_state='expanded')
st.markdown('''<style>
.block-container {padding-top: 1.4rem; max-width: 1500px}
div[data-testid="stMetric"] {border: 1px solid #33415540; border-radius: 9px; padding: 10px 12px}
.small-note {font-size: .84rem; color: #94a3b8}
</style>''', unsafe_allow_html=True)


@st.cache_resource(show_spinner=False)
def load_demo_engine(kind, stamp):
    """Cache only immutable replay engine; refresh when checkpoint changes."""
    return ReplayEngine(ROOT, CONFIG, model_kind=kind)


def selected_engine(kind):
    checkpoint = ROOT / 'artifacts/models' / f'{kind}.pt'
    stamp = checkpoint.stat().st_mtime_ns if checkpoint.exists() else 0
    return load_demo_engine(kind, stamp)


def execute_script(script_name, args, timeout=1800):
    """Execute same backend scripts the README and notebook use."""
    command = [sys.executable, str(ROOT / 'scripts' / script_name), *args]
    completed = subprocess.run(command, cwd=ROOT, capture_output=True, text=True,
                               timeout=timeout, check=False)
    if completed.returncode:
        st.error(f'{script_name} failed (exit {completed.returncode}).')
        st.code((completed.stdout + '\n' + completed.stderr)[-8000:], language='text')
        return False
    st.success(f'Completed: {script_name}')
    st.code((completed.stdout + '\n' + completed.stderr)[-8000:], language='text')
    load_demo_engine.clear()
    return True


def page_overview():
    st.title('Maritime Radar AI')
    st.caption('Radar/ARPA trajectory forecasting • Synthetic proof of concept • 3-second sampling')
    st.warning('DEMONSTRATION ONLY — Synthetic sensor data. No outputs are validated for navigation or collision avoidance.')
    cols = st.columns(4)
    for col, label, value in zip(cols,
                                 ['Training duration', 'Live replay', 'Radar targets', 'Sampling interval'],
                                 ['4 h', '30 min', '3', '3 sec']):
        col.metric(label, value)
    st.subheader('How the integrated demonstration works')
    st.markdown('''
    1. **Simulation Lab** creates continuous physically moving vessels, noisy RADAR observations and own-ship GPS/gyro measurements.
    2. **Model Training** trains GRU and LSTM on 3-minute input windows to predict 5-minute target trajectories. A constant-velocity predictor is the baseline.
    3. **Live Radar** replays synchronized measurements every three seconds, reconstructs tracks and runs inference on the latest 60 historical readings.
    4. **Evaluation** scores models on **held-out encounter episodes**, not random overlapping windows.

    **Critical distinction:** ARPA already estimates speed, course, CPA and TCPA. The experiment tests whether history-aware ML predicts *future vessel movement* better than a conventional constant-velocity forecast.
    ''')
    st.subheader('Current project files')
    rows = []
    for name in ('train', 'demo'):
        folder = ROOT / 'data' / name
        own_path = folder / f'own_ship_{name}.csv'
        rattm_path = folder / f'rattm_{name}_log.csv'
        if own_path.exists() and rattm_path.exists():
            own = pd.read_csv(own_path)
            radar = pd.read_csv(rattm_path)
            rows.append({'Dataset': name.upper(), 'Own-ship ticks': len(own),
                         'RATTM sentences': len(radar),
                         'Distinct target IDs': radar.target_id.nunique()})
    if rows:
        st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    else:
        st.info('Generate the datasets in Simulation Lab first.')
    st.info('Suggested presentation: show the raw RATTM messages → visualize radar tracks → trigger a risky scenario → compare GRU vs CV prediction → show held-out evaluation.')


def page_simulation():
    st.title('Simulation Lab')
    st.caption('Generate realistic, physically connected vessel motion and sensor observations.')
    st.markdown('''Each RATTM row is derived from a physical target-to-own-ship range and bearing. The generator adds range/bearing noise, missed detections, acquisition delays, and causal ARPA-like speed/course and CPA/TCPA estimates.''')
    c1, c2 = st.columns(2)
    with c1:
        st.subheader('Training traffic')
        st.metric('Duration', '12 episodes × 20 min = 4 hours')
        st.caption('8 training episodes, 2 validation episodes, 2 unseen test episodes. 3 targets and 1 own ship per episode.')
        if st.button('Generate / regenerate training data', use_container_width=True):
            with st.spinner('Simulating four hours of ship traffic...'):
                execute_script('generate_data.py', ['--partition', 'train'], timeout=120)
    with c2:
        st.subheader('Independent radar replay')
        st.metric('Duration', '30 minutes @ 3 sec')
        st.caption('Different random seed. Scripted turning maneuvers at several points, intentional radar dropouts and mixed encounter geometry.')
        if st.button('Generate / regenerate demo data', use_container_width=True):
            with st.spinner('Simulating live demo encounter...'):
                execute_script('generate_data.py', ['--partition', 'demo'], timeout=120)
    st.markdown('**Important:** if you change config.yaml and regenerate training data, retrain the model before comparing predictions.')
    p = ROOT / 'data/demo/rattm_demo.nmea'
    if p.exists():
        with open(p, encoding='ascii') as file:
            raw = ''.join(file.readline() for _ in range(8)).strip()
        st.subheader('Actual generated NMEA 0183 sentences')
        st.code(raw, language='text')
        st.caption('The paired *_log.csv file preserves the full timestamp and encounter ID; the .nmea file contains native checksummed messages.')
        st.download_button('Download demo RATTM', p.read_bytes(), file_name='rattm_demo.nmea', mime='text/plain')


def page_training():
    st.title('Model Training')
    st.caption('The same PyTorch training code is called from the notebook, CLI and this dashboard.')
    try:
        import torch
        accelerator = (torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU (no CUDA torch installation detected)')
    except ImportError:
        accelerator = 'PyTorch not installed'
    st.info(f'Compute device: **{accelerator}**. On an RTX 3050, install the appropriate CUDA-enabled PyTorch wheel (README).')
    c1, c2, c3 = st.columns(3)
    with c1:
        model = st.selectbox('Model to train', ['gru', 'lstm', 'both'], index=2)
    with c2:
        epochs = st.number_input('Maximum epochs', min_value=1, max_value=100, value=18)
    with c3:
        amp = st.checkbox('CUDA mixed precision', value=False, help='Optional GPU AMP; disable if unstable.')
    st.markdown('''**What training means:** A model sees 60 past radar-derived observations (3 minutes) and learns a correction to a 100-step (5-minute) constant-velocity forecast. Future true target positions are used only as training labels.''')
    if st.button('Train selected model(s)', type='primary', use_container_width=True):
        with st.spinner('Training PyTorch model(s); this runs in the current app process environment...'):
            args = ['--model', model, '--epochs', str(epochs)] + (['--amp'] if amp else [])
            execute_script('train.py', args, timeout=2400)
    history_file = ROOT / 'artifacts/metrics/training_history.json'
    if history_file.exists():
        history = json.loads(history_file.read_text(encoding='utf-8'))
        st.subheader('Actual saved training history')
        for name, item in history.items():
            st.markdown(f'**{name.upper()}** — Best validation ADE: {item["best_val_ade_m"]:.1f} m')
            if item['history']:
                df = pd.DataFrame(item['history']).set_index('epoch')
                st.line_chart(df[['val_ade_m', 'val_fde_m']])
    st.caption('Training uses episodes 0–7; tuning/early stopping uses episodes 8–9; episodes 10–11 are held out for testing.')


def _radar_figure(frame):
    fig = go.Figure()
    targets = frame['targets']
    if targets:
        own_xy = np.array(targets[0]['own_en'], dtype=float)
        own_v = np.array(targets[0]['own_velocity_en'], dtype=float)
    else:
        own_xy, own_v = np.zeros(2), np.zeros(2)
    # Own ship remains at origin of display, but its projected future changes.
    own_path = np.array([own_xy + own_v * (k+1)*3 for k in range(100)])
    own_relative = (own_path - own_xy) / NM
    fig.add_trace(go.Scatter(x=own_relative[:, 0], y=own_relative[:, 1],
                             mode='lines', name='Own planned path',
                             line=dict(color='#38bdf8', dash='dot', width=2)))
    fig.add_trace(go.Scatter(x=[0], y=[0], mode='markers+text', name='Own ship',
                             marker=dict(color='#38bdf8', size=14, symbol='diamond'),
                             text=['OWN'], textposition='bottom center'))
    for target in targets:
        tid = int(target['target_id'])
        color = COLOR.get(f'{tid:02d}', '#fb923c')
        history = (np.asarray(target['history_en'], dtype=float) - own_xy) / NM
        current = (np.asarray(target['current_en'], dtype=float) - own_xy) / NM
        cv = (np.asarray(target['cv_forecast_en'], dtype=float) - own_xy) / NM
        fig.add_trace(go.Scatter(x=history[:, 0], y=history[:, 1], mode='lines',
                                 name=f'T{tid:02d} observed history',
                                 line=dict(color=color, width=2)))
        fig.add_trace(go.Scatter(x=[current[0]], y=[current[1]], mode='markers+text',
                                 name=f'T{tid:02d} current',
                                 marker=dict(color=color, size=11, symbol='triangle-up'),
                                 text=[f'T{tid:02d}'], textposition='top center'))
        fig.add_trace(go.Scatter(x=cv[:, 0], y=cv[:, 1], mode='lines',
                                 name=f'T{tid:02d} constant-velocity',
                                 line=dict(color=color, dash='dot', width=1)))
        if target['ai_forecast_en'] is not None:
            ai = (np.asarray(target['ai_forecast_en'], dtype=float) - own_xy) / NM
            fig.add_trace(go.Scatter(x=ai[:, 0], y=ai[:, 1], mode='lines',
                                     name=f'T{tid:02d} AI forecast',
                                     line=dict(color=color, dash='dash', width=3)))
    # Radar range rings in NM from the own ship.
    for radius in (1, 2, 4, 8, 12):
        fig.add_shape(type='circle', x0=-radius, y0=-radius, x1=radius, y1=radius,
                      line=dict(color='rgba(52,211,153,0.12)', width=1))
    fig.add_hline(y=0, line_color='rgba(52,211,153,.15)')
    fig.add_vline(x=0, line_color='rgba(52,211,153,.15)')
    fig.update_layout(template='plotly_dark', height=570, margin=dict(l=10,r=10,t=15,b=10),
                      paper_bgcolor='#0b1723', plot_bgcolor='#0b1723',
                      xaxis_title='East relative to own ship (NM)',
                      yaxis_title='North relative to own ship (NM)',
                      legend=dict(orientation='h', y=-.23, x=0),
                      font=dict(color='#cbd5e1'))
    fig.update_yaxes(scaleanchor='x', scaleratio=1, zeroline=False)
    fig.update_xaxes(zeroline=False)
    return fig


def page_live():
    st.title('Live Radar Replay')
    st.caption('Thirty-minute prerecorded synthetic radar feed replayed as a synchronized stream — 3 seconds per scan.')
    st.warning('AI risk bands are experimental separation heuristics, not calibrated collision probabilities or navigational instructions.', icon='⚠️')
    if 'play_idx' not in st.session_state:
        st.session_state.play_idx = 0
    if 'playing' not in st.session_state:
        st.session_state.playing = False
    if 'last_tick_wall' not in st.session_state:
        st.session_state.last_tick_wall = time.monotonic()
    model_kind = st.selectbox('Predictor', ['gru', 'lstm'], format_func=str.upper, index=0)
    try:
        engine = selected_engine(model_kind)
    except (FileNotFoundError, ValueError) as error:
        st.error(str(error) + '. Generate data or retrain to match config.')
        return
    speed = st.select_slider('Replay speed', options=[1, 2, 5, 10], value=1,
                             format_func=lambda v: f'{v}×')
    a, b, c, d, e = st.columns(5)
    if a.button('▶ Play', use_container_width=True):
        st.session_state.playing = True
        st.session_state.last_tick_wall = time.monotonic()
    if b.button('⏸ Pause', use_container_width=True):
        st.session_state.playing = False
    if c.button('↦ +3 s', use_container_width=True):
        st.session_state.playing = False
        st.session_state.play_idx = min(len(engine.own)-1, st.session_state.play_idx+1)
    if d.button('↦ +5 min', use_container_width=True):
        st.session_state.playing = False
        st.session_state.play_idx = min(len(engine.own)-1, st.session_state.play_idx+100)
    if e.button('↺ Reset', use_container_width=True):
        st.session_state.playing = False
        st.session_state.play_idx = 0
    st.caption('At 1×, the system consumes a synchronized own-ship tick and all available target RATTM observations every 3 seconds. Faster replay processes intervening ticks in order.')

    @st.fragment(run_every='1s')
    def live_fragment():
        if st.session_state.playing:
            now = time.monotonic()
            steps = int((now - st.session_state.last_tick_wall) * speed / 3)
            if steps > 0:
                current = st.session_state.play_idx
                next_step = min(len(engine.own)-1, current + steps)
                # Even accelerated playback calls prediction at every skipped
                # intermediate 3-second observation, not just the last frame.
                for k in range(current + 1, next_step + 1):
                    engine.frame_at(k)
                st.session_state.play_idx = next_step
                st.session_state.last_tick_wall += steps * 3 / speed
                if next_step >= len(engine.own) - 1:
                    st.session_state.playing = False
        index = st.session_state.play_idx
        frame = engine.frame_at(index)
        st.progress((index+1) / len(engine.own), text=f"Scan {index+1} / {len(engine.own)} • UTC {frame['timestamp']}")
        m1, m2, m3, m4 = st.columns(4)
        m1.metric('Own ship heading', f"{frame['own_heading_deg']:.1f}°")
        m2.metric('Own ship speed', f"{frame['own_sog_kn']:.1f} kn")
        m3.metric('Tracked targets', len(frame['targets']))
        m4.metric('Inference', 'GRU/LSTM' if frame['model_loaded'] else 'CV BASELINE')
        colplot, coltable = st.columns([1.65, 1], gap='large')
        with colplot:
            st.plotly_chart(_radar_figure(frame), use_container_width=True,
                            config={'displaylogo': False})
        with coltable:
            st.subheader('Current targets')
            table = []
            for target in frame['targets']:
                table.append({
                    'Target': f"T{target['target_id']:02d}",
                    'Model status': target['status'],
                    'Risk band': target['ai_risk']['band'],
                    'Projected min (NM)': target['ai_risk']['min_separation_nm'],
                    'Time to min (min)': target['ai_risk']['time_to_min_min'],
                    'Radar CPA (NM)': target['radar_cpa_nm'],
                    'Radar TCPA (min)': target['radar_tcpa_min'],
                    'Observation age (s)': target['observed_age_seconds'],
                })
            st.dataframe(pd.DataFrame(table), use_container_width=True, hide_index=True)
            st.markdown('**Reading the plot**')
            st.markdown('- **Solid**: observed radar history.\n- **Dotted**: conventional constant velocity.\n- **Dashed**: trained model forecast (only if model loaded and enough history).')
            if not frame['model_loaded']:
                st.error('No checkpoint found. Train the model first; the app is showing only conventional prediction.')
            elif index < int(CONFIG['ml']['input_steps']) - 1:
                st.info('Model warm-up: waiting for 60 past ticks (~3 minutes). Conventional forecasts are available now.')
        st.caption('Projection assumes unchanged own-ship course and speed for the next five minutes. Own-ship future actions and the targets’ actual future are not supplied to inference.')
    live_fragment()


def page_evaluation():
    st.title('Evaluation')
    st.caption('Actual test-episode forecasts, evaluated with held-out synthetic ground truth.')
    if st.button('Compute held-out evaluation', type='primary'):
        with st.spinner('Evaluating models and generating comparison chart...'):
            execute_script('evaluate.py', [], timeout=240)
    file = ROOT / 'artifacts/metrics/evaluation.json'
    if not file.exists():
        st.info('Use the evaluation button above after generating datasets and training.')
        return
    result = json.loads(file.read_text(encoding='utf-8'))
    st.markdown(f"**{result['dataset']}** — {result['test_windows']} test windows")
    st.caption(result['data_warning'])
    models = result['models']
    table = pd.DataFrame([{'Model': name.upper(), **values} for name, values in models.items()])
    st.dataframe(table, use_container_width=True, hide_index=True)
    st.subheader('Trajectory errors — lower is better')
    error = table.set_index('Model')[[c for c in ('ADE_m', 'FDE_m') if c in table]]
    st.bar_chart(error)
    plot_file = ROOT / 'outputs/plots/comparison.png'
    if plot_file.exists():
        st.subheader('Held-out encounter trajectory comparison')
        st.image(str(plot_file))
    st.caption('Risk is defined as a close approach threshold under the same future constant-course OWN-ship hypothesis for all predictors. Not an actual collision probability.')


PAGE = st.sidebar.radio('CONTROL CENTER', ['Overview', 'Live Radar', 'Simulation Lab',
                                           'Model Training', 'Evaluation'])
st.sidebar.divider()
st.sidebar.markdown('**Maritime Radar AI**')
st.sidebar.caption('Synthetic-only research POC • NMEA RATTM • 3-second synchronized data')
st.sidebar.caption('Steps: Simulation → Training → Evaluation → Live Radar')

if PAGE == 'Overview':
    page_overview()
elif PAGE == 'Live Radar':
    page_live()
elif PAGE == 'Simulation Lab':
    page_simulation()
elif PAGE == 'Model Training':
    page_training()
else:
    page_evaluation()
