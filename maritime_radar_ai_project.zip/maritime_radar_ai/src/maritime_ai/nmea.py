"""NMEA 0183 RATTM serializer/parser.

The TTM definition here follows the widely documented 15-field IEC 61162-1
variant. Source: gpsd's NMEA Revealed and Furuno radar operator manuals.

Fields after RATTM:
 01 target ID                  09 TCPA (minutes, signed)
 02 range                     10 speed/distance units K/N/S
 03 bearing                   11 target name
 04 bearing reference T/R     12 status L/Q/T
 05 estimated target speed    13 reference target (usually blank)
 06 estimated target course   14 UTC hhmmss.ss (may be blank in real feeds)
 07 course reference T/R      15 acquisition A/M/R
 08 DCPA

Important: A true-course (T) value is expected for motion conversion in this
POC. Some real radars emit relative courses, use nonstandard fields, or leave
speed/course empty. Determine their actual semantics before real integration.
"""
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class TargetMessage:
    target_id: int
    range_nm: float
    bearing_deg: float
    bearing_reference: str
    speed_kn: float | None
    course_deg: float | None
    course_reference: str
    cpa_nm: float | None
    tcpa_min: float | None
    status: str
    utc_time: str
    acquisition: str = 'A'
    name: str = ''


def nmea_checksum(body):
    """XOR checksum for characters between '$' and '*'."""
    checksum = 0
    for char in body:
        checksum ^= ord(char)
    return f'{checksum:02X}'


def format_nmea(body):
    return f'${body}*{nmea_checksum(body)}'


def _optional(value, decimals):
    return '' if value is None or not math.isfinite(float(value)) else f'{value:.{decimals}f}'


def encode_ttm(msg: TargetMessage):
    """Format a 15-field RATTM sentence; end-of-line is added by writer."""
    fields = [
        f'{msg.target_id:02d}', f'{msg.range_nm:.3f}', f'{msg.bearing_deg:.2f}',
        msg.bearing_reference, _optional(msg.speed_kn, 2),
        _optional(msg.course_deg, 2), msg.course_reference,
        _optional(msg.cpa_nm, 3), _optional(msg.tcpa_min, 2),
        'N', msg.name, msg.status, '', msg.utc_time, msg.acquisition
    ]
    return format_nmea('RATTM,' + ','.join(fields))


def _parse_optional(value):
    return None if value == '' else float(value)


def parse_ttm(line):
    """Validate checksum and parse one RATTM sentence.

    Explicitly rejects malformed or unsupported units instead of guessing.
    A production parser should also profile exact vendor formatting/version.
    """
    line = line.strip()
    if not line.startswith('$') or '*' not in line:
        raise ValueError('Not a checksummed NMEA sentence')
    body, actual = line[1:].rsplit('*', 1)
    if nmea_checksum(body) != actual.upper():
        raise ValueError('NMEA checksum mismatch')
    parts = body.split(',')
    if parts[0] != 'RATTM' or len(parts) != 16:
        raise ValueError(f'Expected RATTM plus 15 fields, got {parts[0]} / {len(parts)-1}')
    f = parts[1:]
    if f[3] not in ('T', 'R') or f[6] not in ('T', 'R'):
        raise ValueError('Invalid bearing/course reference')
    if f[9] not in ('N', 'K', 'S'):
        raise ValueError('Unsupported units')
    multiplier = {'N': 1.0, 'K': 1.0 / 1.852, 'S': 1.0 / 1.150779448}[f[9]]
    return TargetMessage(
        target_id=int(f[0]), range_nm=float(f[1]) * multiplier,
        bearing_deg=float(f[2]), bearing_reference=f[3],
        speed_kn=None if f[4] == '' else float(f[4]) * multiplier,
        course_deg=_parse_optional(f[5]), course_reference=f[6],
        cpa_nm=None if f[7] == '' else float(f[7]) * multiplier,
        tcpa_min=_parse_optional(f[8]), status=f[11],
        utc_time=f[13], acquisition=f[14], name=f[10]
    )
