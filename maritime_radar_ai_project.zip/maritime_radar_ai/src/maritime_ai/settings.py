"""Load central project configuration; ALL scripts and the dashboard share it."""
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]


def load_config(path=None):
    """Return configuration dict from config.yaml (or explicit path)."""
    with open(Path(path) if path else ROOT / 'config.yaml', encoding='utf-8') as file:
        return yaml.safe_load(file)
