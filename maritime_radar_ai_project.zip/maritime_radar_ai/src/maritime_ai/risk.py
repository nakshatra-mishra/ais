"""Transparent, non-certified close-approach *heuristic*, not collision odds.

A collision probability needs calibration and tested uncertainty models. This
prototype reports deterministic distances and advisory bands only. COLREG
obligations are not modeled. NEVER use the output for navigation decisions.
"""
import numpy as np
from .geometry import NM, min_predicted_separation


def assess_path(anchor, future_target_positions, cfg):
    own_pos = np.array([anchor.own_x_m, anchor.own_y_m], dtype=float)
    own_vel = np.array([anchor.own_vx_mps, anchor.own_vy_mps], dtype=float)
    dm, sec = min_predicted_separation(own_pos, own_vel, future_target_positions,
                                       int(cfg['project']['interval_seconds']))
    nm = dm / NM
    if nm < float(cfg['risk']['high_threshold_nm']):
        label = 'HIGH'
    elif nm < float(cfg['risk']['medium_threshold_nm']):
        label = 'MEDIUM'
    else:
        label = 'LOW'
    return {'band': label, 'min_separation_nm': round(float(nm), 3),
            'time_to_min_min': round(float(sec / 60), 2)}
