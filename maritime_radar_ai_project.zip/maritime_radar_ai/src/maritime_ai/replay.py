"""Causal synchronized playback and in-memory per-target inference.

All source records have a timestamp. Each call to `frame_at(step)` uses only
positions and features at <= step, and projects forward for risk. Ground-truth
files are NOT loaded by ReplayEngine, by design.
"""
from pathlib import Path
import numpy as np
from .geometry import NM
from .preprocessing import (read_partition, reconstruct_tracks, make_feature_window,
                            constant_velocity_forecast)
from .ml import load_forecaster, predict_batch
from .risk import assess_path


class ReplayEngine:
    def __init__(self, root, cfg, model_kind='gru'):
        self.root = Path(root)
        self.cfg = cfg
        self.own, self.radar = read_partition(self.root, 'demo')
        self.tracks = reconstruct_tracks(self.own, self.radar, cfg)
        self.own = self.own.sort_values('timestamp').reset_index(drop=True)
        self.target_frames = {int(k[1]): f.sort_values('step').set_index('step', drop=False)
                              for k, f in self.tracks.groupby(['episode_id', 'target_id'])}
        self.model = self.payload = self.device = None
        self.model_kind = model_kind
        checkpoint = self.root / 'artifacts' / 'models' / f'{model_kind}.pt'
        if checkpoint.exists():
            self.model, self.payload, self.device = load_forecaster(checkpoint)
            if (int(self.payload['input_steps']) != int(cfg['ml']['input_steps']) or
                int(self.payload['interval_seconds']) != int(cfg['project']['interval_seconds'])):
                raise ValueError('Checkpoint input grid differs from config. Retrain the model.')

    def frame_at(self, step):
        """Single 3s own-ship row plus every target's RATTM row at this tick.

        Current observations and historical track values only. Not a preview of
        future measured positions; all future curves are *forecasts*.
        """
        step = int(np.clip(step, 0, len(self.own) - 1))
        current_own = self.own.iloc[step]
        result = {
            'step': step, 'timestamp': current_own.timestamp,
            'own_lat': float(current_own.lat), 'own_lon': float(current_own.lon),
            'own_heading_deg': float(current_own.heading_deg),
            'own_sog_kn': float(current_own.sog_kn),
            'targets': [], 'model_loaded': self.model is not None,
            'model_name': self.model_kind,
        }
        history_len = int(self.cfg['ml']['input_steps'])
        horizon = int(self.cfg['ml']['horizon_steps'])
        dt = int(self.cfg['project']['interval_seconds'])
        for target_id, frame in self.target_frames.items():
            if step not in frame.index:
                continue
            past = frame[frame.index <= step].tail(history_len)
            anchor = past.iloc[-1]
            if anchor.measurement_age_s > 15:
                continue  # do not show stale target track as fresh
            forecast_cv = constant_velocity_forecast(anchor, horizon, dt)
            status = 'WARMING UP'
            forecast_ai = None
            if self.model is not None and len(past) == history_len and past.step.iloc[0] == step - history_len + 1:
                x = make_feature_window(past)[None, ...]
                anchor_xy = np.array([anchor.target_x_m, anchor.target_y_m])
                ai_delta = predict_batch(self.model, self.payload, self.device,
                                         x, (forecast_cv - anchor_xy)[None, ...])[0]
                forecast_ai = ai_delta + anchor_xy
                status = 'AI ACTIVE'
            elif self.model is None:
                status = 'CV ONLY — TRAIN FIRST'
            active_forecast = forecast_ai if forecast_ai is not None else forecast_cv
            visible_history = frame[(frame.index <= step) & (frame.index > step-100)].copy()
            target = {
                'target_id': target_id, 'track_status': str(anchor.track_status),
                'observation_present': bool(anchor.measurement_present),
                'observed_age_seconds': float(anchor.measurement_age_s),
                'status': status,
                'current_en': [float(anchor.target_x_m), float(anchor.target_y_m)],
                'own_en': [float(anchor.own_x_m), float(anchor.own_y_m)],
                'own_velocity_en': [float(anchor.own_vx_mps), float(anchor.own_vy_mps)],
                'history_en': visible_history[['target_x_m', 'target_y_m']].to_numpy().tolist(),
                'cv_forecast_en': forecast_cv.tolist(),
                'ai_forecast_en': forecast_ai.tolist() if forecast_ai is not None else None,
                'radar_cpa_nm': round(float(anchor.arpa_cpa_m) / NM, 3),
                'radar_tcpa_min': round(float(anchor.arpa_tcpa_s) / 60, 2),
                'ai_risk': assess_path(anchor, active_forecast, self.cfg),
                'cv_risk': assess_path(anchor, forecast_cv, self.cfg),
            }
            result['targets'].append(target)
        return result
