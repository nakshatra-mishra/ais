"""PyTorch trajectory forecaster and reproducible training utilities.

Architecture: GRU or LSTM reads the latest 60 timesteps and predicts a
100x2 *correction* to the conventional constant-velocity path. This residual
form makes physics-based extrapolation an explicit comparison/fallback rather
than pretending learned trajectories are automatically superior.

Labels are future target simulator truth (for synthetic training only), NEVER
future RATTM/own-ship values in the input. Features are shared with inference.
"""
from copy import deepcopy
import json
import random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


class TrajectoryForecaster(nn.Module):
    def __init__(self, kind='gru', input_features=12, hidden_size=64,
                 num_layers=2, dropout=0.1, horizon_steps=100):
        super().__init__()
        if kind not in ('gru', 'lstm'):
            raise ValueError('kind must be gru or lstm')
        recurrent = nn.GRU if kind == 'gru' else nn.LSTM
        self.core = recurrent(input_features, hidden_size, num_layers=num_layers,
                              batch_first=True, dropout=dropout if num_layers > 1 else 0.0)
        self.head = nn.Sequential(nn.LayerNorm(hidden_size),
                                  nn.Linear(hidden_size, 128), nn.ReLU(),
                                  nn.Linear(128, horizon_steps * 2))
        self.horizon_steps = horizon_steps

    def forward(self, x):
        output, _ = self.core(x)
        return self.head(output[:, -1, :]).reshape(-1, self.horizon_steps, 2)


def select_device():
    return torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def set_seeds(seed=2026):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    else:
        # Avoid enormous CPU thread pools on shared servers / desktop CPUs.
        torch.set_num_threads(min(4, max(1, torch.get_num_threads())))


def fit_scaler(train_x):
    mean = train_x.mean(axis=(0, 1)).astype(np.float32)
    std = train_x.std(axis=(0, 1)).astype(np.float32)
    std[std < .0001] = 1.0
    return mean, std


def normalized(x, mean, std):
    return np.clip((x - mean[None, None, :]) / std[None, None, :], -15, 15).astype(np.float32)


def _dataloader(x, y, cv, mean, std, residual_scale, batch_size, shuffle, cuda):
    features = torch.from_numpy(normalized(x, mean, std))
    residuals = torch.from_numpy(((y - cv) / residual_scale).astype(np.float32))
    truth = torch.from_numpy(y.astype(np.float32))
    baseline = torch.from_numpy(cv.astype(np.float32))
    return DataLoader(TensorDataset(features, residuals, truth, baseline),
                      shuffle=shuffle, batch_size=batch_size, pin_memory=cuda)


@torch.no_grad()
def assess(model, loader, device, scale):
    model.eval()
    errors, end_errors, losses, count = 0.0, 0.0, 0.0, 0
    for features, residual, truth, baseline in loader:
        features, residual = features.to(device), residual.to(device)
        pred = model(features).float()
        losses += nn.functional.smooth_l1_loss(pred, residual, reduction='mean').item() * len(features)
        predicted_xy = pred.cpu().numpy() * scale + baseline.numpy()
        err = np.linalg.norm(predicted_xy - truth.numpy(), axis=-1)
        errors += float(err.mean(axis=1).sum())
        end_errors += float(err[:, -1].sum())
        count += len(features)
    return {'loss': losses / max(count, 1), 'ade_m': errors / max(count, 1),
            'fde_m': end_errors / max(count, 1)}


def train_one(kind, cfg, data_train, data_val, output_directory,
              epochs=None, device=None, amp=False):
    """Train one model; checkpoint best validation ADE, never test data.

    data_* = (X_history, Y_future_displacements, CV_future_displacements, metadata).
    The scaler is fit on train only. Validation episodes have no overlap.
    """
    set_seeds(int(cfg['project']['seed']))
    device = device or select_device()
    model_cfg = cfg['ml']
    xtrain, ytrain, cvtrain, _ = data_train
    xval, yval, cvval, _ = data_val
    mean, std = fit_scaler(xtrain)
    residual_scale = float(model_cfg['residual_scale_m'])
    batch = int(model_cfg['batch_size'])
    model = TrajectoryForecaster(kind, xtrain.shape[-1],
                                 int(model_cfg['hidden_size']),
                                 int(model_cfg['num_layers']),
                                 float(model_cfg['dropout']),
                                 int(model_cfg['horizon_steps'])).to(device)
    train_loader = _dataloader(xtrain, ytrain, cvtrain, mean, std,
                               residual_scale, batch, True, device.type == 'cuda')
    val_loader = _dataloader(xval, yval, cvval, mean, std,
                             residual_scale, batch, False, device.type == 'cuda')
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(model_cfg['learning_rate']), weight_decay=1e-4)
    num_epochs = int(epochs if epochs is not None else model_cfg['epochs'])
    patience = int(model_cfg['patience'])
    mixed_precision = bool(amp and device.type == 'cuda')
    scaler = torch.amp.GradScaler('cuda', enabled=mixed_precision)
    best_val, best_weights, stale = float('inf'), None, 0
    history = []
    print(f'[{kind.upper()}] {device} | train={len(xtrain)} / val={len(xval)} | '
          f'epochs<={num_epochs} | AMP={mixed_precision}', flush=True)
    for epoch in range(1, num_epochs + 1):
        model.train()
        train_loss, n_seen = 0.0, 0
        for xb, yb, _, _ in train_loader:
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type, enabled=mixed_precision):
                pred = model(xb)
                loss = nn.functional.smooth_l1_loss(pred, yb)
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            scaler.step(optimizer)
            scaler.update()
            train_loss += float(loss.item()) * len(xb)
            n_seen += len(xb)
        val = assess(model, val_loader, device, residual_scale)
        item = {'epoch': epoch, 'train_loss': train_loss / max(n_seen, 1), **{'val_' + k: v for k, v in val.items()}}
        history.append(item)
        print(f'  epoch {epoch:02d}: train_loss={item["train_loss"]:.4f} '
              f'val_ADE={val["ade_m"]:.1f}m val_FDE={val["fde_m"]:.1f}m', flush=True)
        if val['ade_m'] < best_val - .001:
            best_val, best_weights, stale = val['ade_m'], deepcopy(model.state_dict()), 0
        else:
            stale += 1
            if stale >= patience:
                print('  early stopping: validation ADE did not improve', flush=True)
                break
    if best_weights is not None:
        model.load_state_dict(best_weights)
    destination = Path(output_directory)
    destination.mkdir(parents=True, exist_ok=True)
    checkpoint = destination / f'{kind}.pt'
    torch.save({
        'kind': kind, 'state_dict': model.cpu().state_dict(),
        'mean': mean.tolist(), 'std': std.tolist(),
        'horizon_steps': int(model_cfg['horizon_steps']),
        'input_steps': int(model_cfg['input_steps']),
        'input_features': xtrain.shape[-1],
        'hidden_size': int(model_cfg['hidden_size']),
        'num_layers': int(model_cfg['num_layers']),
        'dropout': float(model_cfg['dropout']),
        'residual_scale_m': residual_scale,
        'interval_seconds': int(cfg['project']['interval_seconds']),
    }, checkpoint)
    return {'kind': kind, 'checkpoint': str(checkpoint), 'best_val_ade_m': best_val,
            'history': history}


def load_forecaster(checkpoint, device=None):
    device = device or select_device()
    # Only load checkpoints we created/trust; do not ingest untrusted .pt files.
    payload = torch.load(Path(checkpoint), map_location='cpu', weights_only=True)
    model = TrajectoryForecaster(payload['kind'], payload['input_features'],
                                 payload['hidden_size'], payload['num_layers'],
                                 payload['dropout'], payload['horizon_steps'])
    model.load_state_dict(payload['state_dict'])
    model.to(device).eval()
    return model, payload, device


@torch.inference_mode()
def predict_batch(model, payload, device, x, cv):
    mean = np.array(payload['mean'], dtype=np.float32)
    std = np.array(payload['std'], dtype=np.float32)
    xnorm = normalized(np.asarray(x, dtype=np.float32), mean, std)
    tensor = torch.as_tensor(xnorm, dtype=torch.float32, device=device)
    correction = model(tensor).float().cpu().numpy() * float(payload['residual_scale_m'])
    return cv + correction


def save_history(all_runs, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as output:
        json.dump(all_runs, output, indent=2)
