"""Local East-North geometry for <~20 nautical-mile *synthetic* scenarios.

Real deployment: use a geodesic or surveyed ENU projection, antenna/GNSS offsets,
reference frame calibration and sensor timestamps. Do not navigate using these
simplified synthetic coordinates.
"""
import math
import numpy as np

NM = 1852.0
KNOT = NM / 3600.0
EARTH_RADIUS_M = 6378137.0


def wrap360(deg):
    return float(deg) % 360.0


def angular_difference(target, current):
    """Smallest signed (target-current) turn angle, degrees in [-180,180)."""
    return (target - current + 180.0) % 360.0 - 180.0


def vector_from_course(speed_kn, course_deg):
    """Speed in knots, compass true bearing (N=0, E=90) -> east,north m/s."""
    radians = math.radians(course_deg)
    return np.array([speed_kn * KNOT * math.sin(radians),
                     speed_kn * KNOT * math.cos(radians)], dtype=float)


def speed_course_from_vector(velocity):
    """EN velocity (m/s) -> speed knots, true course degrees."""
    vx, vy = np.asarray(velocity, dtype=float)
    return float(math.hypot(vx, vy) / KNOT), wrap360(math.degrees(math.atan2(vx, vy)))


def range_bearing(relative_en):
    """Relative displacement target-own EN metres -> distance NM, true bearing."""
    x, y = np.asarray(relative_en, dtype=float)
    return float(math.hypot(x, y) / NM), wrap360(math.degrees(math.atan2(x, y)))


def relative_position(range_nm, true_bearing_deg):
    """Range/bearing -> EN offset in metres."""
    angle = math.radians(true_bearing_deg)
    return np.array([range_nm * NM * math.sin(angle),
                     range_nm * NM * math.cos(angle)], dtype=float)


def en_to_latlon(east_m, north_m, origin_lat, origin_lon):
    """Local equirectangular inverse; sufficiently close for this POC's range."""
    lat = origin_lat + math.degrees(north_m / EARTH_RADIUS_M)
    lon = origin_lon + math.degrees(east_m / (EARTH_RADIUS_M * math.cos(math.radians(origin_lat))))
    return float(lat), float(lon)


def latlon_to_en(lat, lon, origin_lat, origin_lon):
    return np.array([(lon - origin_lon) * math.pi / 180 * EARTH_RADIUS_M * math.cos(math.radians(origin_lat)),
                     (lat - origin_lat) * math.pi / 180 * EARTH_RADIUS_M], dtype=float)


def cpa_tcpa(relative_en_m, relative_velocity_en_mps):
    """Unbounded mathematical CPA; clamp to a future horizon for risk elsewhere.

    Returns (DCPA in metres, signed TCPA in seconds). If speeds are near equal,
    closest separation is current range and time is infinity.
    """
    r = np.asarray(relative_en_m, dtype=float)
    v = np.asarray(relative_velocity_en_mps, dtype=float)
    vv = float(v @ v)
    if vv < 1e-6:
        return float(np.linalg.norm(r)), math.inf
    t = -float(r @ v) / vv
    return float(np.linalg.norm(r + t * v)), float(t)


def min_predicted_separation(own_now, own_velocity, target_future, dt_seconds):
    """Future minimum separation under *constant* own-ship velocity hypothesis.

    The model predicts the TARGET only. Future actual own-ship positions are not
    accessible in inference and must never be fed into the model.
    """
    future = np.asarray(target_future, dtype=float)
    times = np.arange(1, len(future) + 1, dtype=float) * dt_seconds
    own_path = np.asarray(own_now, dtype=float)[None, :] + times[:, None] * np.asarray(own_velocity, dtype=float)[None, :]
    distances = np.linalg.norm(future - own_path, axis=1)
    idx = int(np.argmin(distances))
    return float(distances[idx]), float(times[idx])
