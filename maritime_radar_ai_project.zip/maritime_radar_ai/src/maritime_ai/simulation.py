"""Physics-first synthetic vessel traffic + radar/ARPA-like observations.

This simulates *continuous physical trajectories* and then produces noisy
observations, not independent random RATTM fields. The radar's speed/course
come from a rolling least-squares fit to noisy past detections (causal), and
its CPA/TCPA come from those estimates. Synthetic truth is written separately.

It is purpose-built for demonstrations, not a high-fidelity radar signal
processor, ship handling simulator, COLREG decision engine or navigational aid.
"""
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import math
import numpy as np
import pandas as pd

from .geometry import (KNOT, NM, angular_difference, cpa_tcpa,
                       en_to_latlon, range_bearing, relative_position,
                       speed_course_from_vector, vector_from_course, wrap360)
from .nmea import TargetMessage, encode_ttm


@dataclass
class Ship:
    x: float
    y: float
    heading: float
    speed_kn: float
    commanded_heading: float
    commanded_speed_kn: float
    max_turn_deg_s: float = 0.45
    max_acc_kn_s: float = 0.009
    drift_deg: float = 0.0

    def velocity(self):
        # Hull heading and course over ground can differ under drift/current.
        return vector_from_course(self.speed_kn, self.heading + self.drift_deg)

    def step(self, dt):
        turn = angular_difference(self.commanded_heading, self.heading)
        self.heading = wrap360(self.heading + np.clip(turn, -self.max_turn_deg_s * dt,
                                                      self.max_turn_deg_s * dt))
        dv = np.clip(self.commanded_speed_kn - self.speed_kn,
                     -self.max_acc_kn_s * dt, self.max_acc_kn_s * dt)
        self.speed_kn = float(max(0.0, self.speed_kn + dv))
        move = self.velocity() * dt
        self.x += float(move[0])
        self.y += float(move[1])

    def position(self):
        return np.array([self.x, self.y], dtype=float)


@dataclass
class ArpaTrack:
    """Very simplified ARPA tracker. Uses no target ground-truth velocity."""
    history: deque = field(default_factory=lambda: deque(maxlen=12))
    missing_streak: int = 0
    good_streak: int = 0

    def on_missing(self):
        self.missing_streak += 1
        if self.missing_streak >= 3:
            self.history.clear()
            self.good_streak = 0

    def observe(self, sample_time_s, detected_world_en):
        self.missing_streak = 0
        self.good_streak += 1
        self.history.append((sample_time_s, np.asarray(detected_world_en, dtype=float)))
        if len(self.history) < 5:
            return None
        points = np.array([p for _, p in self.history])
        times = np.array([t for t, _ in self.history])
        offset = times - times.mean()
        denom = float(np.dot(offset, offset))
        if denom <= 1e-9:
            return None
        velocity = (offset[:, None] * (points - points.mean(axis=0))).sum(axis=0) / denom
        speed_kn, _ = speed_course_from_vector(velocity)
        if speed_kn > 45:  # implausible tracker fit
            return None
        return velocity


def _make_ships(rng, episode_id, demo):
    """Create an own ship and three encounter targets with reasonable speeds.

    Target starting positions are based on desired CPA geometry under the
    initial velocities; later maneuvers invalidate that straight-line CPA.
    This yields a mix of low-risk, developing-risk and non-risk encounters.
    """
    own_heading = float(rng.uniform(0, 360))
    own_speed = float(rng.uniform(9.5, 14.0))
    own = Ship(x=float(rng.uniform(-1200, 1200)),
               y=float(rng.uniform(-1200, 1200)), heading=own_heading,
               speed_kn=own_speed, commanded_heading=own_heading,
               commanded_speed_kn=own_speed, max_turn_deg_s=0.22,
               max_acc_kn_s=0.004, drift_deg=float(rng.uniform(-1.1, 1.1)))
    kinds = ['head_on', 'crossing_port', 'crossing_starboard',
             'overtaking', 'parallel', 'maneuver']
    targets = []
    descriptions = []
    for i in range(3):
        kind = kinds[(episode_id + i * 2) % len(kinds)] if not demo else ['head_on', 'crossing_port', 'maneuver'][i]
        if kind == 'head_on':
            heading = wrap360(own_heading + 180 + rng.uniform(-14, 14))
            speed = float(rng.uniform(10, 17))
        elif kind == 'crossing_port':
            heading = wrap360(own_heading + 85 + rng.uniform(-18, 18))
            speed = float(rng.uniform(9, 18))
        elif kind == 'crossing_starboard':
            heading = wrap360(own_heading - 85 + rng.uniform(-18, 18))
            speed = float(rng.uniform(9, 18))
        elif kind == 'overtaking':
            heading = wrap360(own_heading + rng.uniform(-10, 10))
            speed = float(min(22, own_speed + rng.uniform(2, 7)))
        elif kind == 'parallel':
            heading = wrap360(own_heading + rng.uniform(-7, 7))
            speed = float(max(6, own_speed + rng.uniform(-2, 2)))
        else:
            heading = wrap360(own_heading + rng.choice([-1, 1]) * rng.uniform(45, 110))
            speed = float(rng.uniform(9, 17))
        velocity_rel = vector_from_course(speed, heading) - own.velocity()
        vmag = float(np.linalg.norm(velocity_rel))
        tca = float(rng.uniform(240, 570) if not demo else rng.uniform(300, 720))
        miss_nm = float(rng.choice([rng.uniform(.08, .35), rng.uniform(.5, 1.1), rng.uniform(1.2, 2.3)]))
        perp = np.array([-velocity_rel[1], velocity_rel[0]]) / max(vmag, .1)
        if vmag < .7 or kind == 'parallel':
            relative_start = perp * (miss_nm + .8) * NM + vector_from_course(1.0, own_heading) * rng.uniform(-2, 2) * NM / KNOT
        else:
            relative_start = -velocity_rel * tca + perp * miss_nm * NM
        relative_start += rng.normal(0, 120, size=2)
        pos = own.position() + relative_start
        target = Ship(x=float(pos[0]), y=float(pos[1]), heading=heading,
                      speed_kn=speed, commanded_heading=heading,
                      commanded_speed_kn=speed,
                      max_turn_deg_s=float(rng.uniform(.25, .60)),
                      max_acc_kn_s=float(rng.uniform(.005, .014)),
                      drift_deg=float(rng.uniform(-.7, .7)))
        targets.append(target)
        descriptions.append(kind)
    return own, targets, descriptions


def _maneuver_commands(own, targets, descriptions, step, interval, minutes,
                       rng, demo, episode_id):
    """Deterministic timed maneuvers, smooth due to each Ship's turn limits."""
    seconds = step * interval
    if step == 0:
        return
    own_events = ([8 * 60, 18 * 60, 26 * 60] if demo
                  else [int(minutes * 60 * .42), int(minutes * 60 * .78)])
    if seconds in own_events:
        own.commanded_heading = wrap360(own.commanded_heading + float(rng.choice([-1, 1]) * rng.uniform(8, 22)))
        own.commanded_speed_kn = float(np.clip(own.speed_kn + rng.uniform(-1.3, 1.3), 8, 16))
    for i, target in enumerate(targets):
        if demo:
            time_events = [[5*60, 14*60, 23*60], [9*60, 19*60, 27*60], [7*60, 16*60, 24*60]][i]
        else:
            first = [5*60, 8*60, 11*60][i]
            time_events = [first, first + 6*60]
        if seconds not in time_events:
            continue
        if descriptions[i] == 'maneuver' and seconds == time_events[0]:
            # Turn toward own ship's projected position (plausible developing threat).
            projected_own = own.position() + own.velocity() * 180
            relative = projected_own - target.position()
            desired = wrap360(math.degrees(math.atan2(relative[0], relative[1])))
            delta = float(np.clip(angular_difference(desired, target.heading), -65, 65))
        else:
            delta = float(rng.choice([-1, 1]) * rng.uniform(12, 55))
        target.commanded_heading = wrap360(target.commanded_heading + delta)
        target.commanded_speed_kn = float(np.clip(target.commanded_speed_kn + rng.uniform(-2, 2.5), 6, 22))


def simulate_episode(cfg, episode_id, start_time, minutes, seed, demo=False):
    """Generate one scenario. Output dataframes: own, target_truth, raw_ttm_log.

    Training episodes are independent even though their UTC timestamps follow
    one another. Each episode gets a separate track_session ID.
    """
    dt = int(cfg['project']['interval_seconds'])
    sim = cfg['simulation']
    rng = np.random.default_rng(seed)
    own, targets, kinds = _make_ships(rng, episode_id, demo)
    trackers = [ArpaTrack(deque(maxlen=int(sim['tracking_history_steps']))) for _ in targets]
    n = int(minutes * 60 / dt)
    own_rows, truth_rows, radar_rows = [], [], []
    gps_origin = (cfg['project']['origin_lat'], cfg['project']['origin_lon'])
    for k in range(n):
        now = start_time + timedelta(seconds=k * dt)
        timestamp = now.isoformat().replace('+00:00', 'Z')
        _maneuver_commands(own, targets, kinds, k, dt, minutes, rng, demo, episode_id)
        if k:
            own.step(dt)
            for target in targets:
                target.step(dt)
        # GPS noise independent of radar measurement noise; radar antenna is
        # idealized collocated with this GPS for the demonstration.
        noisy_own_en = own.position() + rng.normal(0, float(sim['own_gps_noise_m']), size=2)
        lat, lon = en_to_latlon(noisy_own_en[0], noisy_own_en[1], *gps_origin)
        cog = wrap360(own.heading + own.drift_deg)
        own_rows.append({
            'episode_id': episode_id, 'timestamp': timestamp,
            'lat': round(lat, 8), 'lon': round(lon, 8),
            'heading_deg': round(wrap360(own.heading + rng.normal(0, .17)), 3),
            'cog_deg': round(wrap360(cog + rng.normal(0, .13)), 3),
            'sog_kn': round(max(0, own.speed_kn + rng.normal(0, .07)), 3),
            'source': 'SYNTHETIC_GNSS_GYRO', 'scenario': 'demo' if demo else 'training',
        })
        for i, target in enumerate(targets):
            target_id = i + 1
            target_pos = target.position()
            target_vel = target.velocity()
            tlat, tlon = en_to_latlon(target_pos[0], target_pos[1], *gps_origin)
            truth_rows.append({
                'episode_id': episode_id, 'timestamp': timestamp, 'target_id': target_id,
                'track_session_id': f'ep{episode_id:03d}-t{target_id:02d}',
                'true_x_m': round(target_pos[0], 4), 'true_y_m': round(target_pos[1], 4),
                'true_lat': round(tlat, 8), 'true_lon': round(tlon, 8),
                'true_vx_mps': round(target_vel[0], 5), 'true_vy_mps': round(target_vel[1], 5),
                'scenario_type': kinds[i], 'synthetic_truth_only': True,
            })
            rel = target_pos - own.position()
            actual_range_nm, actual_bearing_t = range_bearing(rel)
            # Include intentionally short dropouts (and rarer random misses).
            purposeful_drop = (int((4 + i * 3 + (episode_id % 3)) * 60 / dt) <= k
                                < int((4 + i * 3 + (episode_id % 3)) * 60 / dt) + 4)
            if (actual_range_nm > float(sim['radar_range_nm']) or
                purposeful_drop or rng.random() < float(sim['missing_detection_probability'])):
                trackers[i].on_missing()
                continue
            noisy_range_m = max(1, actual_range_nm * NM + float(rng.normal(0, sim['range_noise_m'])))
            noisy_bearing = wrap360(actual_bearing_t + float(rng.normal(0, sim['bearing_noise_deg'])))
            radar_pos_en = own.position() + relative_position(noisy_range_m / NM, noisy_bearing)
            estimated_vel = trackers[i].observe(k * dt, radar_pos_en)
            # First few observations are acquiring; speed/course/CPA/TCPA
            # may be genuinely absent in a radar's TTM stream.
            status = 'T' if estimated_vel is not None and trackers[i].good_streak >= 7 else 'Q'
            speed = course = cpa_nm = tcpa_min = None
            if estimated_vel is not None and status == 'T':
                speed, course = speed_course_from_vector(estimated_vel)
                d_cpa_m, t_cpa_s = cpa_tcpa(radar_pos_en - own.position(),
                                           estimated_vel - own.velocity())
                cpa_nm = float(min(99.99, d_cpa_m / NM))
                tcpa_min = float(np.clip(t_cpa_s / 60, -99.9, 99.9)) if np.isfinite(t_cpa_s) else None
            # Alternate true/relative BEARING reference by episode; course is
            # always true to avoid treating a relative course as true motion.
            bearing_ref = 'R' if episode_id % 2 else 'T'
            bearing_out = (noisy_bearing - own.heading) % 360 if bearing_ref == 'R' else noisy_bearing
            msg = TargetMessage(target_id, noisy_range_m / NM, bearing_out, bearing_ref,
                                speed, course, 'T', cpa_nm, tcpa_min,
                                status, now.strftime('%H%M%S.00'))
            sentence = encode_ttm(msg)
            radar_rows.append({
                'episode_id': episode_id, 'timestamp': timestamp,
                'target_id': target_id,
                'track_session_id': f'ep{episode_id:03d}-t{target_id:02d}',
                'sentence': sentence,
            })
    return pd.DataFrame(own_rows), pd.DataFrame(truth_rows), pd.DataFrame(radar_rows)


def generate_dataset(cfg, partition='train'):
    """Build 4h training episodes or independent 30m replay episode."""
    if partition not in {'train', 'demo'}:
        raise ValueError('Partition must be train/demo')
    seed = int(cfg['project']['seed'])
    base_time = (datetime(2026, 11, 16, tzinfo=timezone.utc)
                 if partition == 'train' else
                 datetime(2026, 11, 17, 8, tzinfo=timezone.utc))
    if partition == 'train':
        minutes = int(cfg['simulation']['episode_minutes'])
        num_episodes = int(cfg['simulation']['train_episodes'])
    else:
        minutes = int(cfg['simulation']['demo_minutes'])
        num_episodes = 1
    all_own, all_truth, all_radar = [], [], []
    for index in range(num_episodes):
        episode_id = index if partition == 'train' else 1000
        a, b, c = simulate_episode(cfg, episode_id, base_time + timedelta(minutes=index*minutes),
                                   minutes, seed + index*101 + (0 if partition == 'train' else 92000),
                                   demo=partition == 'demo')
        all_own.append(a)
        all_truth.append(b)
        all_radar.append(c)
    return (pd.concat(all_own, ignore_index=True),
            pd.concat(all_truth, ignore_index=True),
            pd.concat(all_radar, ignore_index=True))
