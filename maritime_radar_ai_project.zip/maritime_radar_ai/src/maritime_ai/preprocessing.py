"""Shared deterministic feature pipeline for BOTH training and live inference.

The target's *current* position is reconstructed exclusively from observed
RATTM range/bearing plus own-ship GNSS and heading. The true simulator target
coordinates are never read by this function and are only used as future labels
or after-the-fact evaluation.

All timestamps are exactly 3-second grid positions in the synthetic package.
For real hardware, replace the join with a latency-aware timestamp resampler.
"""
from pathlib import Path
import numpy as np
import pandas as pd

from .geometry import KNOT, NM, latlon_to_en, relative_position, vector_from_course
from .nmea import parse_ttm

FEATURE_NAMES = [
    'history_target_dx_m', 'history_target_dy_m',
    'estimated_target_vx_mps', 'estimated_target_vy_mps',
    'history_own_relative_x_m', 'history_own_relative_y_m',
    'own_vx_mps', 'own_vy_mps',
    'arpa_cpa_m', 'arpa_tcpa_s',
    'measurement_present', 'measurement_age_s',
]


def read_partition(root, partition):
    """Read raw measurement streams. Ground truth is read only when asked."""
    directory = Path(root) / 'data' / partition
    own = pd.read_csv(directory / f'own_ship_{partition}.csv')
    radar = pd.read_csv(directory / f'rattm_{partition}_log.csv')
    return own, radar


def reconstruct_tracks(own_df, radar_df, cfg):
    """Return one record for every target at every 3-second own-ship tick.

    Missing target detections are marked (measurement_present=0). The state
    is *causally* extrapolated using its previous estimated velocity; nothing
    from future observations is used to fill missing measurements.
    """
    lat0 = float(cfg['project']['origin_lat'])
    lon0 = float(cfg['project']['origin_lon'])
    dt = float(cfg['project']['interval_seconds'])
    own_df = own_df.sort_values(['episode_id', 'timestamp']).copy()
    radar_lookup = {}
    for record in radar_df.itertuples(index=False):
        key = (int(record.episode_id), str(record.timestamp), int(record.target_id))
        radar_lookup[key] = str(record.sentence)
    rows = []
    for episode_id, own_episode in own_df.groupby('episode_id', sort=True):
        own_episode = own_episode.reset_index(drop=True)
        for target_id in range(1, int(cfg['simulation']['targets_per_episode']) + 1):
            old_pos = None
            old_velocity = np.zeros(2, dtype=float)
            previous_detected_pos = None
            previous_detected_step = None
            age = 0.0
            for step, own in enumerate(own_episode.itertuples(index=False)):
                own_pos = latlon_to_en(float(own.lat), float(own.lon), lat0, lon0)
                own_velocity = vector_from_course(float(own.sog_kn), float(own.cog_deg))
                message = radar_lookup.get((int(episode_id), str(own.timestamp), target_id))
                observed = int(message is not None)
                if message:
                    parsed = parse_ttm(message)
                    true_bearing = float(parsed.bearing_deg)
                    if parsed.bearing_reference == 'R':
                        true_bearing = (true_bearing + float(own.heading_deg)) % 360
                    measured_pos = own_pos + relative_position(parsed.range_nm, true_bearing)
                    if parsed.speed_kn is not None and parsed.course_deg is not None:
                        if parsed.course_reference != 'T':
                            # A real sensor might mean relative velocity or
                            # own-heading-referenced course. Resolve vendor
                            # semantics before using it in production.
                            raise ValueError('POC requires true target course for speed estimate')
                        estimated_velocity = vector_from_course(parsed.speed_kn, parsed.course_deg)
                    elif previous_detected_pos is not None:
                        elapsed = (step - previous_detected_step) * dt
                        measured_velocity = (measured_pos - previous_detected_pos) / max(elapsed, dt)
                        measured_velocity = np.clip(measured_velocity, -22, 22)
                        estimated_velocity = .15 * measured_velocity + .85 * old_velocity
                    else:
                        estimated_velocity = old_velocity.copy()
                    old_pos = measured_pos
                    old_velocity = estimated_velocity
                    previous_detected_pos = measured_pos
                    previous_detected_step = step
                    age = 0.0
                    cpa = parsed.cpa_nm * NM if parsed.cpa_nm is not None else 0.0
                    tcpa = float(np.clip(parsed.tcpa_min * 60, -6000, 6000)) if parsed.tcpa_min is not None else 0.0
                    status = parsed.status
                else:
                    if old_pos is None:
                        continue  # target has not yet been acquired
                    old_pos = old_pos + old_velocity * dt
                    age += dt
                    cpa = rows[-1]['arpa_cpa_m'] if rows and rows[-1]['episode_id'] == episode_id and rows[-1]['target_id'] == target_id else 0.0
                    tcpa = rows[-1]['arpa_tcpa_s'] if rows and rows[-1]['episode_id'] == episode_id and rows[-1]['target_id'] == target_id else 0.0
                    status = 'MISSING'
                rows.append({
                    'episode_id': int(episode_id), 'timestamp': str(own.timestamp),
                    'step': step, 'target_id': target_id,
                    'track_session_id': f'ep{int(episode_id):03d}-t{target_id:02d}',
                    'target_x_m': float(old_pos[0]), 'target_y_m': float(old_pos[1]),
                    'target_vx_mps': float(old_velocity[0]), 'target_vy_mps': float(old_velocity[1]),
                    'own_x_m': float(own_pos[0]), 'own_y_m': float(own_pos[1]),
                    'own_vx_mps': float(own_velocity[0]), 'own_vy_mps': float(own_velocity[1]),
                    'own_heading_deg': float(own.heading_deg),
                    'arpa_cpa_m': float(cpa), 'arpa_tcpa_s': float(tcpa),
                    'measurement_present': observed, 'measurement_age_s': age,
                    'track_status': status,
                })
    return pd.DataFrame(rows)


def make_feature_window(history):
    """Build a single input tensor from ONLY timestamps <= the current time.

    All spatial positions are translated by the latest measured target position
    so the model is not tied to a specific region's raw GPS coordinates.
    """
    if history.empty:
        raise ValueError('Empty history')
    anchor = history.iloc[-1]
    tx, ty = float(anchor.target_x_m), float(anchor.target_y_m)
    return np.column_stack([
        history['target_x_m'].to_numpy() - tx,
        history['target_y_m'].to_numpy() - ty,
        history['target_vx_mps'].to_numpy(),
        history['target_vy_mps'].to_numpy(),
        history['own_x_m'].to_numpy() - tx,
        history['own_y_m'].to_numpy() - ty,
        history['own_vx_mps'].to_numpy(),
        history['own_vy_mps'].to_numpy(),
        history['arpa_cpa_m'].to_numpy(),
        history['arpa_tcpa_s'].to_numpy(),
        history['measurement_present'].to_numpy(),
        history['measurement_age_s'].to_numpy(),
    ]).astype(np.float32)


def constant_velocity_forecast(anchor, horizon_steps, dt):
    """Causal constant-velocity baseline, in EN metres."""
    start = np.array([anchor.target_x_m, anchor.target_y_m], dtype=float)
    velocity = np.array([anchor.target_vx_mps, anchor.target_vy_mps], dtype=float)
    times = np.arange(1, horizon_steps + 1) * float(dt)
    return start + times[:, None] * velocity[None, :]


def build_examples(tracks, truth, cfg, split='train', stride=None):
    """Create supervised windows. Only TARGET FUTURE TRUTH supplies labels.

    Episode-level splits avoid overlapping windows leaking from train to test.
    Test/validation episodes are wholly unseen in training.
    """
    n_hist = int(cfg['ml']['input_steps'])
    horizon = int(cfg['ml']['horizon_steps'])
    dt = int(cfg['project']['interval_seconds'])
    if stride is None:
        stride = int(cfg['ml']['train_stride'] if split == 'train' else cfg['ml']['evaluation_stride'])
    groups = {
        'train': set(range(0, 8)), 'val': {8, 9}, 'test': {10, 11},
    }
    if split not in groups:
        raise ValueError('split must be train/val/test')
    truth_lookup = {}
    for (ep, target), frame in truth.groupby(['episode_id', 'target_id']):
        truth_lookup[(int(ep), int(target))] = frame.set_index('timestamp')
    inputs, future, baseline, metadata = [], [], [], []
    for (episode, target), track in tracks.groupby(['episode_id', 'target_id'], sort=True):
        episode, target = int(episode), int(target)
        if episode not in groups[split]:
            continue
        frame = track.sort_values('step').reset_index(drop=True)
        true_frame = truth_lookup.get((episode, target))
        if true_frame is None:
            continue
        # Group by step rather than assume a future trajectory exists for a
        # target at missing initial time points.
        step_index = frame.set_index('step', drop=False)
        for t in range(n_hist - 1, int(frame.step.max()) - horizon + 1, stride):
            hist_steps = list(range(t - n_hist + 1, t + 1))
            if not set(hist_steps).issubset(step_index.index):
                continue
            hist = step_index.loc[hist_steps]
            if (hist.measurement_present.mean() < .75 or
                hist.iloc[-1].measurement_age_s > 6):
                continue
            fut_steps = list(range(t + 1, t + horizon + 1))
            # Ownship time grid is complete; align labels by timestamp index.
            target_future_times = []
            valid = True
            for future_step in fut_steps:
                key = step_index.loc[future_step, 'timestamp'] if future_step in step_index.index else None
                if key is None or key not in true_frame.index:
                    valid = False
                    break
                target_future_times.append(key)
            if not valid:
                continue
            future_points = true_frame.loc[target_future_times, ['true_x_m', 'true_y_m']].to_numpy(dtype=np.float32)
            anchor = hist.iloc[-1]
            anchor_pos = np.array([anchor.target_x_m, anchor.target_y_m], dtype=np.float32)
            base_path = constant_velocity_forecast(anchor, horizon, dt).astype(np.float32)
            inputs.append(make_feature_window(hist))
            future.append(future_points - anchor_pos)
            baseline.append(base_path - anchor_pos)
            metadata.append({'episode_id': episode, 'target_id': target,
                             'timestamp': str(anchor.timestamp), 'step': int(t),
                             'own_x_m': float(anchor.own_x_m), 'own_y_m': float(anchor.own_y_m),
                             'own_vx_mps': float(anchor.own_vx_mps), 'own_vy_mps': float(anchor.own_vy_mps)})
    if not inputs:
        raise RuntimeError(f'No examples found for split={split}; check dataset and config.')
    return (np.stack(inputs), np.stack(future), np.stack(baseline), pd.DataFrame(metadata))
