# Maritime Radar AI — Synthetic RATTM, Trajectory Forecasting & Collision-Risk Demonstration

> **RESEARCH / PRESENTATION ONLY.** This code uses **synthetic** vessels, an illustrative radar/ARPA-like tracker, and an experimental ML model. It is **not** certified maritime equipment, is not a collision-avoidance system, does not implement COLREG decision-making, and must **never** be used to navigate a vessel or replace ARPA/radar alarms or the officer of the watch.

## 0. What to run first (five-minute orientation)

This is **one integrated project**, with a Streamlit control-center dashboard, CLI scripts, and a Jupyter notebook all using the same Python modules. The attached archive already includes the **generated four-hour training traffic**, **30-minute independent demo traffic**, and a **small pretrained GRU checkpoint** for a quick demonstration. The checkpoint here was trained briefly on CPU for smoke testing: **retrain GRU and LSTM on your RTX 3050** for the full experiment. The packaged GRU **does not outperform** the constant-velocity baseline on the included test set; this is disclosed rather than hidden.

### Fastest route to a demonstration (no training required)

```bash
# 1. Extract the ZIP and open a terminal INSIDE maritime_radar_ai/
# 2. Set up Python 3.10–3.12 in a fresh virtual environment
python -m venv .venv

# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Windows Command Prompt:
# .venv\Scripts\activate.bat
# macOS/Linux:
# source .venv/bin/activate

# 3. Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 4. Run checks; then launch the presentation
python -m pytest -q
streamlit run app.py
```

Go to **Live Radar** in the browser. The bundled GRU checkpoint is loaded automatically, and simulated observations advance at exactly **one synchronized time tick every 3 seconds** at 1×. All three targets are processed for that timestamp. You can also use 2×/5×/10× replay speeds. The first 60 observations are the historical warm-up; during that period, the system uses constant-velocity estimates.

If your GPU is not active, the app **still works on CPU**. GPU acceleration mainly matters for training.

### Full experiment — recommended for the senior demonstration

Run from the project root, **in this order**:

```bash
# A. Regenerate physically consistent 4h and 30min synthetic datasets (optional: bundled already)
python scripts/generate_data.py

# B. Train BOTH models; optional GPU mixed precision shown later
python scripts/train.py --model both --epochs 18

# C. Evaluate them on held-out simulated episodes 10 and 11
python scripts/evaluate.py

# D. Run tests
python -m pytest -q

# E. Launch a single, integrated dashboard
streamlit run app.py
```

You can do steps A, B, and C from the dashboard's **Simulation Lab**, **Model Training**, and **Evaluation** pages if you prefer, but CLI output is easier to diagnose. **Don't regenerate training data and then compare old model checkpoints as if they were newly trained.**

### Dedicated NVIDIA RTX 3050 setup

First check that the GPU and its driver are visible:

```bash
nvidia-smi
```

For **CUDA-enabled** PyTorch, choose the installation command matching your operating system, Python, CUDA runtime and driver from the **official PyTorch installer**: https://pytorch.org/get-started/locally/ . Install that PyTorch build in the activated virtual environment, then install this project's other requirements. A generic `pip install torch` does **not** guarantee CUDA is available on every machine.

Verify in Python:

```bash
python -c "import torch; print('torch:', torch.__version__, 'CUDA:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"
```

Then train with optional automatic mixed precision if CUDA is supported:

```bash
python scripts/train.py --model both --epochs 18 --amp
```

If VRAM is limited or an out-of-memory error appears, lower `ml.batch_size` from 128 to 32 or 64 in `config.yaml`. The demo is small enough that the training may be limited more by data diversity than GPU throughput. An RTX 3050's available VRAM varies by model; the code detects CUDA rather than assuming a memory size.

## 1. What the system demonstrates

**Objective:** learn target-vessel motion from a time series of radar/ARPA RATTM messages, forecast **five minutes** ahead, and compute hypothetical own-ship/target **minimum predicted separation**, alongside conventional CPA/TCPA.

```text
                         SIMULATED PHYSICAL WORLD
                         Own ship + 3 target ships
                                     |
                           Sensor simulation
       +-----------------------------+-----------------------------+
       |                             |                             |
Own ship GNSS, gyro, SOG       Radar range/bearing            Hidden world truth
 own_ship_*.csv                + ARPA-like tracker            ground_truth_*.csv
       |                        rattm_*.nmea                      |
       |                       rattm_*_log.csv                    |
       +-----------------------------+                             |
                                     |                             |
                     Synchronized, causal data processing        |
                                     |                             |
                    Radar-relative -> global local EN position    |
                    Track histories + missing-detection masks      |
                                     |                             |
                     60 past ticks = 3-minute input               |
                                     |                             |
                       GRU or LSTM prediction                      |
                                     |                             |
             100 future ticks = 5-minute trajectory prediction     |
                                     |                             |
                  Risk from predicted minimum separation           |
                                     |                             |
                   Streamlit radar / presentation view             |
                                                                   |
                           Offline evaluation <------------------+
                      (labels never fed to live inference)
```

### Why not simply reproduce the radar's CPA/TCPA?

ARPA already estimates speed, course, CPA and TCPA under tracking/motion assumptions. The actual research question is whether **history-aware** ML can forecast ship maneuvers better than a constant-velocity estimate. Therefore the interface plots both and the evaluator computes held-out ADE/FDE. An AI model is **not automatically better**.

## 2. Exact synthetic data quantities and timing

Configured in `config.yaml`:

| Parameter | Value |
|---|---|
| Radar + own-ship interval | **3 seconds everywhere** |
| Training | **12 independent 20-minute scenarios** = **4 hours**, with 3 targets per scenario |
| Training own-ship rows | **4,800** (12 × 400) |
| Potential training target messages | 14,400 before dropout/acquisition |
| Actual bundled training RATTM messages | **14,084** |
| Demo replay | **30 minutes**, a separate seeded scenario |
| Demo own-ship rows | **600** |
| Actual bundled demo RATTM messages | **1,766** |
| Model input | Past 60 × 3 sec = **3-minute** track history |
| Model output | Next 100 × 3 sec = **5-minute** forecast |
| Model input feature count | 12 per radar target |
| Split | Episodes **0–7 train** (160 min), **8–9 validation** (40 min), **10–11 test** (40 min) |

**Important:** Four hours/three concurrent targets is only a small synthetic proof of concept, even with multiple episodes and thousands of sliding windows. It is **not** a robust marine ML training corpus. In real deployment, collect data from many vessels, routes, sea states, operating modes and encounter types. The demo's 30 minutes are **not** included in training.

## 3. What's inside the extracted folder?

```text
maritime_radar_ai/
├── README.md                       <-- START HERE
├── requirements.txt               <-- Python dependencies
├── config.yaml                    <-- All simulator, ML, and risk settings
├── app.py                         <-- Unified Streamlit control center
│
├── src/maritime_ai/
│   ├── settings.py                <-- Read config.yaml
│   ├── geometry.py                <-- Local East-North, bearings, CPA/TCPA
│   ├── nmea.py                    <-- True RATTM sentence format + XOR checksum
│   ├── simulation.py              <-- Ship physics, ARPA-like tracking, noise
│   ├── preprocessing.py           <-- NMEA parsing, synchronization, ML windows
│   ├── ml.py                      <-- PyTorch GRU/LSTM, training, checkpoints
│   ├── risk.py                    <-- Deterministic separation risk bands
│   └── replay.py                  <-- 3-sec synchronized replay and inference
│
├── scripts/
│   ├── generate_data.py          <-- RUN FIRST if regenerating data
│   ├── train.py                  <-- RUN SECOND to train GRU/LSTM
│   ├── evaluate.py               <-- RUN THIRD for held-out scores/plot
│   └── run_replay.py             <-- Optional CLI replay, no Streamlit needed
│
├── notebooks/
│   └── training_walkthrough.ipynb <-- Annotated actual end-to-end notebook
│
├── data/
│   ├── train/
│   │   ├── own_ship_train.csv      4,800 rows of 3-sec own-ship state
│   │   ├── rattm_train.nmea        Raw checksummed RATTM sentences
│   │   ├── rattm_train_log.csv     Time/episode metadata + NMEA sentence
│   │   └── ground_truth_train.csv  Hidden true target trajectory (labels only)
│   └── demo/
│       ├── own_ship_demo.csv       600 rows of 3-sec own-ship state
│       ├── rattm_demo.nmea        Raw checksummed RATTM sentences
│       ├── rattm_demo_log.csv     Time-associated radar observations
│       └── ground_truth_demo.csv  Offline truth; NOT read in replay inference
│
├── artifacts/
│   ├── models/
│   │   └── gru.pt                 Bundled quick/demo checkpoint; train LSTM yourself
│   └── metrics/
│       ├── training_history.json
│       └── evaluation.json
│
├── outputs/plots/
│   └── comparison.png             Saved held-out trajectory comparison
└── tests/
    └── test_pipeline.py           Parser, geometry, no-peeking, and split tests
```

### Data file contracts

- `own_ship_*.csv`: one observation per **3-second** tick. `timestamp`, `episode_id`, GPS (`lat/lon`), heading, COG, SOG. The GPS and gyro values are noisy but come from the own ship's **physical** simulated state.
- `rattm_*.nmea`: **one message per target observed**. Some targets are missing at a given tick. Does **not** contain full dates or episode boundaries, because these are not fields of standard RATTM messages.
- `rattm_*_log.csv`: each sentence paired with `timestamp`, `episode_id`, `target_id`, and a synthetic track session ID. **Use this file to synchronize the demo.** All messages for the current timestamp are read together with the one current own-ship row.
- `ground_truth_*.csv`: the underlying true target positions and velocities. Used to generate future-position labels and evaluation, **never exposed to the model's input or replay engine**.

**Why separate `.nmea` and `.csv` logs?** A standalone RATTM sentence identifies a radar target and may contain only a *time of day* (or none); it cannot reliably provide an absolute UTC date or globally unique track identity. The logger metadata avoids accidentally combining different targets or independent voyages.

Example NMEA syntax:

```text
$RATTM,<target>,<range>,<bearing>,T|R,<speed>,<course>,T,<CPA>,<TCPA>,N,,T,,<UTC>,A*<checksum>
```

The parser verifies the XOR checksum and understands true (`T`) or relative (`R`) **bearing** references; its simplified kinematics require **true course** for speed/course. Actual commercial sensors may emit different optional fields and units. Do **not** assume a vendor's nonstandard RATTM message works until the fields are verified using its manual or recorded examples.

## 4. How synthetic RATTM is generated (step-by-step)

1. **Initialize a scenario:** give each of the four ships position, speed, heading, commanded heading, turn-rate limit, acceleration and a small current/drift offset. Construct head-on, crossing, overtaking, parallel and maneuver encounters using plausible relative velocities.
2. **Integrate motion every 3 sec:** vessels do not teleport; heading and speed change only within configured maneuver limits.
3. **Compute physical radar observation:** calculate target-to-own distance and true bearing at that instant.
4. **Apply sensor limitations:** 18 m standard deviation range noise, 0.18° bearing noise, probability-based missed detections and deliberate short dropouts. These are example synthetic parameters, **not** a claim about your radar accuracy.
5. **Estimate ARPA-like motion causally:** use a rolling fit of **previous noisy observations**, not the target's hidden true speed or course. Mark early observations as acquiring (`Q`); later tracked observations as `T`. Derive CPA/TCPA from estimated relative motion.
6. **Encode real NMEA formatting:** serialize fields in `$RATTM,...*XX`, where `XX` is an actual XOR checksum.
7. **Keep simulator truth separately:** store true target positions for future supervised labels.

This is deliberately **more realistic than randomly generating independent RATTM fields**, but it is still a simplified radar/ARPA software simulation. It does **not** model radar returns, Doppler spectra, sea clutter, multipath, blind sectors, antenna mounting errors, calibrated probability of detection, or a commercial vendor's tracking algorithm.

## 5. How the GRU and LSTM work

**Features for each 3-second target history row:**

| # | Feature | Meaning |
|---:|---|---|
| 1–2 | Target relative EN displacement (m) | Historical target locations translated to newest target position |
| 3–4 | Target velocity EN (m/s) | Causal radar/ARPA estimate |
| 5–6 | Own ship EN relative to target (m) | Observer/target geometry |
| 7–8 | Own ship velocity EN (m/s) | From SOG/COG, not heading alone |
| 9 | ARPA CPA (m) | Current radar-derived estimate |
| 10 | ARPA TCPA (s) | Current radar-derived estimate |
| 11 | Observation mask | 1 if detected, 0 if inferred through a missing reading |
| 12 | Age of observation (sec) | Freshness/reliability of radar state |

Input has shape `(batch, 60, 12)`. The GRU/LSTM (two recurrent layers, 64 hidden units by default) outputs a **100 × 2 future displacement correction**, added to the **constant-velocity forecast**. The training labels are synthetic future *true target positions*, expressed relative to the last current target location. It is a **residual model**, not an autonomous ship-motion policy.

Training:

- Fit normalization mean/std on **training episodes only**.
- Optimize smooth-L1 loss on residual trajectories, AdamW optimizer, gradient clipping, and early stopping by validation **ADE**.
- Choose the best validation checkpoint without touching test episodes.
- Train GRU or LSTM with `python scripts/train.py --model gru|lstm|both`.
- Checkpoints include model weights, input scaler, grid interval, and model hyperparameters.
- Inference recomputes the **same 12 features** from radar observations and applies the saved scaler.

**No leakage:** training labels use future truth; live inference uses only received observations at or before the current tick. The code includes a regression test that changing future observations cannot change reconstructed past states. Whole episodes (not overlapping 3-second windows) are held out.

## 6. How the 30-minute replay really works

Each replay tick = **one own-ship CSV row plus all target RATTM sentences recorded for the same time**. It is **not** one target message per tick. The parser converts range/bearing to local east/north offsets using the simultaneous own-ship GPS position and heading if the RATTM bearing is `R`; if bearing is `T`, heading is not added.

Each tracked target receives a time-history buffer. If a detection is missing, its previous state is **causally extrapolated** and marked missing; stale targets are excluded. The baseline projects target motion at its last estimated velocity. After **60 historical points (~3 minutes)**, the GRU/LSTM projects 100 future points. A risk calculator compares that target path against a hypothetical own-ship constant-course/speed path over the five-minute horizon.

**Risk** is a configurable **separation band** (`HIGH` if future minimum < 0.4 NM; `MEDIUM` if < 1.0 NM; otherwise `LOW`). These thresholds are arbitrary **demonstration heuristics**, not calibrated collision probabilities, COLREG rules, class-approved alarm limits, or universal safety distances.

The UI draws past target positions (solid), constant-velocity future (dotted), GRU/LSTM future (dashed), and the assumed own-ship path. It displays radar CPA/TCPA as a reference and makes model availability/warm-up visible. Use **Evaluation** to show where the trained model succeeds/fails against the physics baseline.

### CLI playback without opening the dashboard

```bash
# Read all 600 ticks quickly; no real-time delay
python scripts/run_replay.py --model gru --max-steps 30 --no-sleep

# Actual 3-second timing
python scripts/run_replay.py --model gru --speed 1

# 10x presentation speed: 3 sec of simulated time per 0.3 sec wall time
python scripts/run_replay.py --model gru --speed 10
```

## 7. Jupyter notebook (technical walkthrough)

```bash
python -m pip install notebook
jupyter notebook notebooks/training_walkthrough.ipynb
```

The notebook imports **the exact same** `src/maritime_ai` functions as `scripts/train.py`. It contains markdown explanation, inspection of NMEA messages, sensor data checks, time-series windows, held-out splits, actual GRU/LSTM training, metrics/plots, and inference. **Launch it from the project root** as shown so its files resolve correctly. Notebook training will overwrite the existing checkpoints if you run the training cells; evaluation should follow.

## 8. Suggested senior presentation (10–15 minutes)

1. **Overview**: explain why RATTM works even for non-AIS targets, and that true/relative bearing needs own-ship navigation references.
2. **Simulation Lab**: display actual `$RATTM` sentences and the separate own-ship/ground-truth files. Explain physical simulation + ARPA-like noise, not random numbers.
3. **Live Radar**: run playback, show 3 targets and historical tracks. Jump ahead ~5 minutes using the button to skip warm-up; compare conventional and AI trajectory lines.
4. **Model Training**: show CUDA detection, validation training curves, and checkpoints. Explain the model only receives the **past** 60 observations.
5. **Evaluation**: show held-out ADE/FDE and close-encounter window metrics. Highlight that **a physics baseline can beat ML** on this small dataset. Propose improvement with real sea-trial data, maneuver classes and uncertainty-aware forecasting.
6. **Future integration**: replace synthetic stream generator with a read-only recorder for your radar's RATTM and synchronized GNSS/HDT/SOG/COG. Shadow-test predictions against approved systems; do not control the radar or helm.

## 9. Existing benchmark results in the shipped example

The bundled GRU was trained for **only three epochs on CPU**, so that the package includes a tested inference checkpoint. On the two held-out **synthetic** test episodes, the current recorded scores are:

| Model | ADE (metres; lower better) | FDE at 5 minutes (metres) |
|---|---:|---:|
| Constant velocity | **245.83** | **609.66** |
| Bundled 3-epoch GRU | 286.56 | 702.41 |

In other words, **the current GRU is worse than the conventional baseline**. This is expected to be possible with scarce training data. The correct aim of this proof of concept is an **honest, working experimental platform** and a route to stronger models—not to claim AI is safer or more accurate without evidence. The packaged `evaluation.json` contains the actual metrics; they will update if you retrain and reevaluate.

## 10. Tests and troubleshooting

```bash
python -m pytest -q
python -m compileall -q src scripts app.py
```

- **`ModuleNotFoundError`**: make sure the virtual environment is active and install `requirements.txt` from **the extracted project folder**, not elsewhere.
- **CUDA reports `False`**: run `nvidia-smi`; install a matching CUDA-enabled torch build from the official PyTorch installation selector; relaunch terminal/IDE. CPU fallback is valid.
- **GPU out of memory**: lower `ml.batch_size` and restart training.
- **Dashboard says `CV ONLY`**: train a model or check that `artifacts/models/gru.pt` or `lstm.pt` exists.
- **Checkpoint/grid mismatch**: restore `config.yaml` to 3-second interval / 60 input points / 100 future points or regenerate and retrain consistently.
- **Radar target temporarily disappears**: some missing scans are intentional; status and age fields describe this. The dashboard should not silently fill future data.
- **NMEA unit/field mismatch with your actual radar**: inspect actual manufacturer sentence examples and modify `nmea.py` first. A true (`T`) bearing is already north-referenced; relative (`R`) bearings must add gyro heading, not COG.
- **Why is the simulation not perfectly realistic?** The goal is a credible end-to-end prototype. Real ARPA tracking, clutter/multipath, hydrodynamics, antenna offset, and data association need more engineering and validation.
- **Why does 4 h yield thousands of ML examples?** The dataset is chopped into overlapping 3-minute-history/5-minute-future windows; these are **correlated**, not thousands of independent real voyages.

## 11. Limitations before real radar integration

You will need: verified vendor-specific RATTM semantics, time synchronization and absolute UTC dates; own-ship GPS and gyro antenna offsets; accurate SOG/COG sources and compass calibration; track-loss and ID-reuse handling; range/bearing error modeling and sea-trial validation; explicit maneuvering own-ship hypotheses; safeguards for stale/invalid radar tracks; uncertainty calibration, COLREG-aware logic and human factors review; appropriate class/flag/regulatory approval if a navigation-support product is contemplated.

The present prototype neither communicates with an actual marine radar nor issues navigational commands. It is **safe as an offline replay research demonstration**, but its outputs are **not suitable for real-world collision avoidance**.

---

**Project sequence to remember:** `Generate → Train (GRU/LSTM) → Evaluate → Launch dashboard → Replay 3-second scan ticks → Present findings`.
