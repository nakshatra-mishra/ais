"""Honest held-out evaluation: test episodes 10–11 were never trained on.

Outputs artifacts/metrics/evaluation.json and outputs/plots/comparison.png.
No model is *required*; in that case evaluation includes CV baseline only.
"""
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.preprocessing import read_partition, reconstruct_tracks, build_examples
from maritime_ai.ml import load_forecaster, predict_batch
from maritime_ai.geometry import NM


def metric_table(predictions, actual, inputs, cfg):
    dt = int(cfg['project']['interval_seconds'])
    diff = np.linalg.norm(predictions - actual, axis=2)
    metrics = {'ADE_m': round(float(diff.mean()), 2),
               'FDE_m': round(float(diff[:, -1].mean()), 2)}
    for minute in (1, 3, 5):
        index = min(int(minute*60 / dt) - 1, diff.shape[1] - 1)
        metrics[f'error_at_{minute}min_m'] = round(float(diff[:, index].mean()), 2)
    # Reference own ship is *hypothetically constant course and speed* after t.
    # Both baseline and ML use the SAME own-ship hypothesis. Future truth
    # TARGET positions are only used by the evaluator, never by inference.
    time_steps = np.arange(1, predictions.shape[1] + 1)[None, :, None] * dt
    ownfuture = (inputs[:, -1, 4:6][:, None, :] +
                 inputs[:, -1, 6:8][:, None, :] * time_steps)
    true_dmin = np.linalg.norm(actual - ownfuture, axis=2).min(axis=1)
    pred_dmin = np.linalg.norm(predictions - ownfuture, axis=2).min(axis=1)
    risk_threshold = float(cfg['risk']['high_threshold_nm']) * NM
    positives = true_dmin < risk_threshold
    predicted_positives = pred_dmin < risk_threshold
    tp = int(np.sum(positives & predicted_positives))
    fp = int(np.sum(~positives & predicted_positives))
    fn = int(np.sum(positives & ~predicted_positives))
    metrics['high_risk_positive_windows'] = int(positives.sum())
    metrics['risk_precision'] = round(tp / (tp + fp), 3) if (tp + fp) else None
    metrics['risk_recall'] = round(tp / (tp + fn), 3) if (tp + fn) else None
    metrics['risk_false_positive_windows'] = fp
    metrics['risk_missed_positive_windows'] = fn
    return metrics


def evaluate_all(cfg=None):
    cfg = cfg or load_config()
    own, radar = read_partition(ROOT, 'train')
    truth = pd.read_csv(ROOT / 'data/train/ground_truth_train.csv')
    tracks = reconstruct_tracks(own, radar, cfg)
    x, y, cv, info = build_examples(tracks, truth, cfg, 'test')
    results = {'dataset': 'held-out synthetic test episodes 10 and 11',
               'test_windows': int(len(x)),
               'sampling_seconds': int(cfg['project']['interval_seconds']),
               'forecast_minutes': 5,
               'risk_definition': 'Min future separation < configured high threshold, under constant own-course/speed hypothesis',
               'data_warning': 'Adjacent sliding windows are correlated; not independent encounters.',
               'models': {'constant_velocity': metric_table(cv, y, x, cfg)}}
    saved_predictions = {'constant_velocity': cv}
    for kind in ('gru', 'lstm'):
        checkpoint = ROOT / 'artifacts/models' / f'{kind}.pt'
        if not checkpoint.exists():
            continue
        model, payload, device = load_forecaster(checkpoint)
        forecasts = []
        for start in range(0, len(x), 128):
            forecasts.append(predict_batch(model, payload, device,
                                           x[start:start+128], cv[start:start+128]))
        predicted = np.concatenate(forecasts, axis=0)
        saved_predictions[kind] = predicted
        results['models'][kind] = metric_table(predicted, y, x, cfg)
    dest = ROOT / 'artifacts/metrics/evaluation.json'
    dest.parent.mkdir(parents=True, exist_ok=True)
    with open(dest, 'w', encoding='utf-8') as output:
        json.dump(results, output, indent=2)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        # Choose a genuinely changing test trajectory by maximum CV FDE.
        index = int(np.argmax(np.linalg.norm(cv[:, -1] - y[:, -1], axis=1)))
        fig, ax = plt.subplots(figsize=(9, 6))
        ax.plot(y[index, :, 0] / NM, y[index, :, 1] / NM, label='Synthetic future truth', linewidth=2.5)
        ax.plot(cv[index, :, 0] / NM, cv[index, :, 1] / NM, '--', label='Constant velocity')
        for kind in ('gru', 'lstm'):
            if kind in saved_predictions:
                pred = saved_predictions[kind][index]
                ax.plot(pred[:, 0] / NM, pred[:, 1] / NM, label=kind.upper() + ' predicted')
        ax.scatter([0], [0], marker='x', s=85, label='Prediction origin')
        ax.set_xlabel('Target displacement east (NM)')
        ax.set_ylabel('Target displacement north (NM)')
        ax.axis('equal')
        ax.grid(alpha=.25)
        ax.set_title('Held-out test encounter — 5-minute target forecast')
        ax.legend()
        output_file = ROOT / 'outputs/plots/comparison.png'
        output_file.parent.mkdir(parents=True, exist_ok=True)
        fig.tight_layout()
        fig.savefig(output_file, dpi=160)
        plt.close(fig)
    except Exception as err:
        print('Plot creation skipped:', err)
    print(json.dumps(results, indent=2))
    print(f'Saved {dest}')
    return results


if __name__ == '__main__':
    evaluate_all()
