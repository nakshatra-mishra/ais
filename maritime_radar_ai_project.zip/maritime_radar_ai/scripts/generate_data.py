"""Generate both 4-hour training and 30-minute independent demo datasets.

Run from repository root: python scripts/generate_data.py
"""
import argparse
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.simulation import generate_dataset


def generate(which):
    cfg = load_config()
    own, truth, radar = generate_dataset(cfg, which)
    directory = ROOT / 'data' / which
    directory.mkdir(parents=True, exist_ok=True)
    own.to_csv(directory / f'own_ship_{which}.csv', index=False)
    truth.to_csv(directory / f'ground_truth_{which}.csv', index=False)
    radar.to_csv(directory / f'rattm_{which}_log.csv', index=False)
    # Native NMEA sentence lines can be fed to parsers; the paired CSV is needed
    # to preserve full dates, target associations, and episode boundaries.
    with open(directory / f'rattm_{which}.nmea', 'w', encoding='ascii', newline='') as output:
        for sentence in radar.sentence:
            output.write(sentence + '\r\n')
    print(f'{which}: {len(own):,} own-ship ticks; {len(truth):,} truth points; '
          f'{len(radar):,} RATTM messages -> {directory}')
    return own, truth, radar


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--partition', choices=['train', 'demo', 'both'], default='both')
    args = parser.parse_args()
    for partition in (['train', 'demo'] if args.partition == 'both' else [args.partition]):
        generate(partition)
