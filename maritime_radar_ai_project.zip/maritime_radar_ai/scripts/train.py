"""Train GRU and/or LSTM on synthetic training episodes only.

Run after generate_data.py. Examples:
  python scripts/train.py --model gru --epochs 10
  python scripts/train.py --model both --epochs 18 --amp
"""
import argparse
import sys
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.preprocessing import read_partition, reconstruct_tracks, build_examples
from maritime_ai.ml import train_one, save_history, select_device


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', choices=['gru', 'lstm', 'both'], default='both')
    parser.add_argument('--epochs', type=int, default=None)
    parser.add_argument('--amp', action='store_true', help='Use CUDA automatic mixed precision when available')
    args = parser.parse_args()
    cfg = load_config()
    own, radar = read_partition(ROOT, 'train')
    truth = pd.read_csv(ROOT / 'data/train/ground_truth_train.csv')
    tracks = reconstruct_tracks(own, radar, cfg)
    train = build_examples(tracks, truth, cfg, 'train')
    val = build_examples(tracks, truth, cfg, 'val')
    print(f'Training windows: {len(train[0])}, validation windows: {len(val[0])}. '
          'Held-out test episodes 10–11 excluded.', flush=True)
    results = {}
    for kind in (['gru', 'lstm'] if args.model == 'both' else [args.model]):
        results[kind] = train_one(kind, cfg, train, val, ROOT / 'artifacts/models',
                                  epochs=args.epochs, device=select_device(), amp=args.amp)
    save_history(results, ROOT / 'artifacts/metrics/training_history.json')
    print('Saved trained model(s) to artifacts/models and history to artifacts/metrics.', flush=True)


if __name__ == '__main__':
    main()
