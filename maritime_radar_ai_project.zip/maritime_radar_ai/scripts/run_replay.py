"""Terminal alternative to dashboard; consumes 3-second timestep per update.

`--speed 1` = real 3-second pause. `--speed 10` = 0.3 seconds per tick.
`--no-sleep` instantly tests a few steps without waiting.
"""
import argparse
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.replay import ReplayEngine


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--speed', type=float, default=1.0)
    parser.add_argument('--model', choices=['gru', 'lstm'], default='gru')
    parser.add_argument('--max-steps', type=int, default=600)
    parser.add_argument('--no-sleep', action='store_true')
    args = parser.parse_args()
    engine = ReplayEngine(ROOT, load_config(), args.model)
    print(f'Playback model available: {engine.model is not None} ({args.model})')
    for step in range(min(args.max_steps, len(engine.own))):
        frame = engine.frame_at(step)
        output = ', '.join(f"T{t['target_id']:02d}: {t['ai_risk']['band']} "
                           f"{t['ai_risk']['min_separation_nm']:.2f}NM [{t['status']}]"
                           for t in frame['targets'])
        print(f"{frame['timestamp']} | own heading {frame['own_heading_deg']:.1f}deg | {output}", flush=True)
        if not args.no_sleep:
            time.sleep(max(.02, float(engine.cfg['project']['interval_seconds']) / max(.1, args.speed)))


if __name__ == '__main__':
    main()
