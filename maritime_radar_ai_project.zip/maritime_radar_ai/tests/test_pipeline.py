"""Regression tests for sentence validity, synchronization, and no future leakage."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from maritime_ai.settings import load_config
from maritime_ai.geometry import (NM, en_to_latlon, latlon_to_en, cpa_tcpa,
                                  relative_position, range_bearing)
from maritime_ai.nmea import TargetMessage, encode_ttm, parse_ttm
from maritime_ai.preprocessing import read_partition, reconstruct_tracks, build_examples
from maritime_ai.replay import ReplayEngine


def test_rattm_checksum_roundtrip():
    msg = TargetMessage(1, 3.23, 130.2, 'R', 12.3, 245.1, 'T', .41, 5.2, 'T', '120003.00')
    raw = encode_ttm(msg)
    assert raw.startswith('$RATTM,')
    assert len(raw.split('*')[0].split(',')) == 16
    result = parse_ttm(raw)
    assert result.target_id == 1 and result.status == 'T'
    assert result.bearing_reference == 'R' and result.course_reference == 'T'
    with pytest.raises(ValueError):
        parse_ttm(raw[:-2] + '00')


def test_blank_acquisition_fields_roundtrip():
    msg = TargetMessage(2, 2.0, 60.0, 'T', None, None, 'T', None, None, 'Q', '120000.00')
    decoded = parse_ttm(encode_ttm(msg))
    assert decoded.speed_kn is None and decoded.tcpa_min is None


def test_local_geometry_roundtrip():
    lat0, lon0 = 17.5, 71.5
    for en in (np.array([1000., 2000.]), np.array([-3400., 5900.])):
        lat, lon = en_to_latlon(en[0], en[1], lat0, lon0)
        np.testing.assert_allclose(latlon_to_en(lat, lon, lat0, lon0), en, atol=1e-6)
        r, b = range_bearing(en)
        np.testing.assert_allclose(relative_position(r, b), en, atol=1e-7)


def test_cpa_simple():
    dcpa, tcpa = cpa_tcpa(np.array([1000., 200.]), np.array([-5., 0.]))
    assert abs(dcpa-200) < 1e-8 and abs(tcpa-200) < 1e-8


def test_generated_dataset_has_three_second_intervals():
    own, radar = read_partition(ROOT, 'demo')
    assert len(own) == 600
    assert set(radar.target_id) == {1, 2, 3}
    interval = pd.to_datetime(own.timestamp).diff().dropna().dt.total_seconds()
    assert (interval == 3).all()
    assert all(parse_ttm(s).target_id in (1,2,3) for s in radar.sentence.head(80))


def test_episode_split_windows():
    cfg = load_config()
    own, radar = read_partition(ROOT, 'train')
    tracks = reconstruct_tracks(own, radar, cfg)
    truth = pd.read_csv(ROOT / 'data/train/ground_truth_train.csv')
    partitions = [build_examples(tracks, truth, cfg, split) for split in ('train', 'val', 'test')]
    assert all(x.shape[1:] == (60, 12) and y.shape[1:] == (100, 2)
               for x, y, cv, meta in partitions)
    a, b, c = [set(p[3].episode_id) for p in partitions]
    assert not (a & b or a & c or b & c)


def test_live_preprocessing_does_not_peek_at_future():
    """Changing future radar records must not alter reconstructed past states."""
    cfg = load_config()
    own, radar = read_partition(ROOT, 'demo')
    n = 95
    last_time = own.iloc[n-1].timestamp
    full = reconstruct_tracks(own, radar, cfg)
    past_only = reconstruct_tracks(own.iloc[:n], radar[radar.timestamp <= last_time], cfg)
    full_past = full[full.step < n].reset_index(drop=True)
    assert len(full_past) == len(past_only)
    np.testing.assert_allclose(full_past[['target_x_m', 'target_y_m', 'target_vx_mps']].to_numpy(),
                               past_only[['target_x_m', 'target_y_m', 'target_vx_mps']].to_numpy(), rtol=0, atol=1e-9)


def test_replay_cv_fallback_is_explicit():
    eng = ReplayEngine(ROOT, load_config(), model_kind='gru')
    frame = eng.frame_at(110)
    assert len(frame['targets']) >= 1
    for t in frame['targets']:
        assert t['ai_risk']['band'] in ('HIGH', 'MEDIUM', 'LOW')
        assert len(t['cv_forecast_en']) == 100
        if eng.model is None:
            assert t['ai_forecast_en'] is None
            assert 'CV ONLY' in t['status']
